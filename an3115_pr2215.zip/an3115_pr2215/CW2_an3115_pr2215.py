
# coding: utf-8

# # Coursework 2 
# ### Perform k-nearest neighbour (KNN) retrieval experiments according to standard practices in pattern recognition. Use retrieval error (ie @rank1, @rank10) as the performance metric to evaluate different methods. Your baseline approach is KNN on provided features. Use distance metric learning methods to improve a baseline performance.

# #### So, firstly, we need to create a baseline, which is KNN on provided features. 

# In[9]:


from scipy.io import loadmat
train_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['train_idx'].flatten()


# ## Load features

# In[10]:


import json
import numpy as np
import matplotlib.pyplot as plt

with open("PR_data/feature_data.json", "r") as file:
    features = json.load(file)
    
data_features = np.asarray(features)

print('Data shape: {}'.format(data_features.shape))


# ## Load data

# In[11]:


#Load labels
labelss = loadmat('cuhk03_new_protocol_config_labeled.mat')['labels'].flatten()

#Load camId
cam_Ids = loadmat('cuhk03_new_protocol_config_labeled.mat')['camId'].flatten()

#Load indexes
train_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['train_idx'].flatten()
query_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['query_idx'].flatten()
gallery_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['gallery_idx'].flatten()

#Load training indexes
print("training indexes : {}".format(train_idxs.shape))
print("query indexes : {}".format( query_idxs.shape))
print("gallery indexes : {}".format( gallery_idxs.shape))


# In[12]:


#converting to python index notation

train_idxs = train_idxs - 1
query_idxs = query_idxs - 1
gallery_idxs = gallery_idxs - 1


# ## Separate the features and data into training, query and gallery sets 

# In[246]:


train_f = []
train_label = []
train_camid = []
# divide the features data into training 
for i in range (len(train_idxs)):
    train_f.append(data_features[train_idxs[i]])
    train_camid.append(cam_Ids[train_idxs[i]])
    train_label.append(labelss[train_idxs[i]])
    
train_f = np.asarray(train_f)    
train_label = np.asarray(train_label)
train_camid = np.asarray(train_camid)


# In[14]:


#features, cam, label data into gallery
query_f = []
query_camid = []
query_label = []

for i in range (len(query_idxs)):
    query_f.append(data_features[query_idxs[i]])
    query_camid.append(cam_Ids[query_idxs[i]])
    query_label.append(labelss[query_idxs[i]])
    
query_f = np.asarray(query_f) 
query_label = np.asarray(query_label)
query_camid = np.asarray(query_camid)


# In[15]:


#features, cam, label data into gallery
gallery_f = []
gallery_camid = []
gallery_label = []

for i in range (len(gallery_idxs)):
    gallery_f.append(data_features[gallery_idxs[i]])
    gallery_camid.append(cam_Ids[gallery_idxs[i]])
    gallery_label.append(labelss[gallery_idxs[i]])
       
gallery_f = np.asarray(gallery_f)  
gallery_camid = np.asarray(gallery_camid)  
gallery_label = np.asarray(gallery_label)  


# ### Concatenate query and gallery features/labels/cam ids

# In[16]:


#stacking labels, cam ids and features

query = np.vstack((query_f.T, query_label, query_camid)) #transpose feature matrix to match dimensions 
gallery = np.vstack((gallery_f.T, gallery_label, gallery_camid)) #transpose feature matrix to match dimensions 

#transpose back to get right shape
query = query.T
gallery = gallery.T

print(query[:,-2])
print(gallery.shape)


# ## Remove the repetitions of cam ids and labels and perform NN classification

# ## Nearest Neighbor Classification

# In[191]:


from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KNeighborsClassifier

k = 20 #number of nearest neighbors parameter

rank = []
distance = []
idx = []

import time
start_time = time.time()

##sqeuclidean instead of euclidean for computing efficientcy. As we are only interested in the ranklists
##and not the actual values of the distances.

for i in range (len(query[:,0])):
    
    ##getting rid of label/camid repetions 
    gallery_no_rep = gallery[~np.logical_and((gallery[:,-1] == query[i, -1]), (gallery[:,-2] == query[i, -2]))]
    
    NN = NearestNeighbors(n_neighbors = k, metric = 'sqeuclidean') #setting up NN
    NN.fit(gallery_no_rep[:,:-2], gallery_no_rep[:,-2])

   
    query_f_test = query_f[i,:].reshape(1,-1)
    dist, idxs = NN.kneighbors(query_f_test)
    
    distance.append(dist)
    idx.append(idxs)

distance = np.asarray(distance)
idx = np.asarray(idx)

print(idx.shape)

##creating ranklist of predicted labels (1400x10)
for i in range (len(query[:,0])):
    row_rank = []
    for j in range (len(idx[0,:])):
        row_rank.append(gallery[idx[i,j],-2])
    rank.append(row_rank)
    
rank = np.asarray(rank)     

    
print("--- %s seconds ---" % (time.time() - start_time))

print(rank.shape)


# In[192]:


rank = np.squeeze(rank)
print(rank.shape)
print(rank)


# ## Creating a Match/No Match array 

# In[193]:


query_label = query_label.reshape(1400,1)

rank_bin1 = []

for i in range (len(rank[:,0])):
    rank_bin = []
    for j in range (len(rank[0,:])): 
        if (rank[i,j] == query_label[i]):   ##if match, set 1, otherwise set 0
            rank_bin.append(1)
        else:
            rank_bin.append(0)
    rank_bin1.append(rank_bin)
    
    
rank_bin1 = np.asarray(rank_bin1)   ##array of label matches and mismatches
print(rank_bin1)


# ## Rank calculation

# In[194]:


rank_1 = np.sum(rank_bin1[:,0])/1400
r5 = rank_bin1[:,:5].sum(axis = 1)/5
rank_5 = np.count_nonzero(r5)/1400
r10 = rank_bin1[:,:10].sum(axis = 1)/10
rank_10 = np.count_nonzero(r10)/1400

print("Accuracy")
print("rank 1: %s" % (rank_1))
print("rank 5: %s" % (rank_5))
print("rank 10: %s" % (rank_10))


# ## Finding precisions and recalls for calculating the mAP

# ### Test

# In[22]:


X = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0]

total = 0
precision = []
recall = []

for i in range (len(X)):
    total += X[i]
    precision.append(total/(i+1))
    recall.append(total/np.sum(X))
print(recall)


# In[23]:


plt.plot(recall, precision, 'o-')
plt.show()


# In[24]:


total = 0
precision = []
recall = []

row = 8
clm = 5
print("Actual row %s" % (rank_bin1[row, :]))

for i in range (len(rank_bin1[row,:clm])):
    total += rank_bin1[row,i]
    precision.append(total/(i+1))
    recall.append(total/np.sum(rank_bin1[row,:clm]))

precision = np.asarray(precision)
recall = np.asarray(recall)

recall1 = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
recall1 = np.asarray(recall1)

i = recall1.shape[0]-2
j = recall.shape[0]-2

print("Actual precision %s" % (precision))
print("Actual recall %s" % (recall))

plt.plot(recall,precision, '--')



##interpolation of precisions by 11 step recalls
#print("Interp precision %s" %(precision_int))


#while i>0:       
#    if precision_int[i+1]>precision_int[i]:
#        precision_int[i] = precision_int[i+1]
#    i=i-1
while j>=0:       
    if precision[j+1]>precision[j]:
        precision[j] = precision[j+1]
    j=j-1
    
precision_int=np.interp(recall1, recall, precision)

print("Max precision %s" %(precision))

plt.plot(recall,precision, '-x')
plt.plot(recall1, precision_int, 'o-')
plt.show()
AP = np.sum(precision)/(precision.shape)
AP_int = np.sum(precision_int)/(precision_int.shape)
print(AP)
print(AP_int)


# ## Finding mAP

# In[198]:


#mAP for rank1

clm = 5
mAP =[]   
mAP_int=[]  ## mAP array of interpolated precision values

for row in range(1400):
    total = 0
    recall = []
    precision = []
    for i in range (len(rank_bin1[row,:clm])):
        total += rank_bin1[row,i]
        precision.append(total/(i+1))   #calculate precision
        recall.append(total/np.sum(rank_bin1[row,:clm]))    #calculate recall

    precision = np.asarray(precision)
    recall = np.asarray(recall)
    
    recall1 = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]     #11 recall values
    recall1 = np.asarray(recall1)

    i = recall1.shape[0]-2
    j = recall.shape[0]-2
    
    
    ##maximizing precision (smoothening)
    while j>=0:       
        if precision[j+1]>precision[j]:  
            precision[j] = precision[j+1]
        j=j-1
    
    ##interpolation of precision to 11 values 
    precision_int=np.interp(recall1, recall, precision)
    
    AP = np.sum(precision)/(precision.shape)   ##average precision 
    AP_int = np.sum(precision_int)/(precision_int.shape)   ##average interpolated precision 
    
    mAP.append(AP)
    mAP_int.append(AP_int)
        
mAP = np.asarray(mAP)
mAP_int = np.asarray(mAP_int)
mAP_int = np.nan_to_num(mAP_int)


mAP_total = np.sum(mAP, axis = 0)/1400
mAP_int_total = np.sum(mAP_int, axis = 0)/1400

print("mAP: %s" %(mAP_total))
print("mAP: %s" %(mAP_int_total))


# ## Improvement 

# ## PCA

# In[181]:


print(train_f.shape)


# In[247]:


from sklearn.decomposition import PCA
from sklearn.decomposition import KernelPCA

N = 200
pca = PCA(n_components = N)
pca.fit(train_f)
kpca = KernelPCA(n_components = N, kernel = 'cosine')
kpca.fit(train_f)


# In[248]:


#concatenate labels and camera IDs to the train feature vectors
train_f = np.vstack((train_f.T, train_label, train_camid)) 
#transpose feature matrix to match dimensions 

train_f = train_f.T


# In[249]:


k = 10 #number of nearest neighbors parameter

rank = []
distance = []
idx = []

import time
start_time = time.time()

##sqeuclidean instead of euclidean for computing efficientcy. As we are only interested in the ranklists
##and not the actual values of the distances.

for i in range (len(query[:,0])):
    
    ##getting rid of label/camid repetions 
    gallery_no_rep = gallery[~np.logical_and((gallery[:,-1] == query[i, -1]), (gallery[:,-2] == query[i, -2]))]
    
    query_f_test = query_f[i,:].reshape(1,-1)
    query_f_pca = pca.transform(query_f_test)

    gallery_f_pca = pca.transform(gallery_no_rep[:,:-2])
    
    NN = NearestNeighbors(n_neighbors = k, metric = 'sqeuclidean') #setting up NN
    NN.fit(gallery_f_pca, gallery_no_rep[:,-2])

   
    #query_f_test = query_f[i,:].reshape(1,-1)
    dist, idxs = NN.kneighbors(query_f_pca)
    
    distance.append(dist)
    idx.append(idxs)

distance = np.asarray(distance)
idx = np.asarray(idx)

print(idx.shape)

##creating ranklist of predicted labels (1400x10)
for i in range (len(query[:,0])):
    row_rank = []
    for j in range (len(idx[0,:])):
        row_rank.append(gallery[idx[i,j],-2])
    rank.append(row_rank)
    
rank = np.asarray(rank)     

    
print("--- %s seconds ---" % (time.time() - start_time))

print(rank.shape)


# In[250]:


rank = np.squeeze(rank)
print(rank.shape)
print(rank)


# In[251]:


query_label = query_label.reshape(1400,1)

rank_bin1 = []

for i in range (len(rank[:,0])):
    rank_bin = []
    for j in range (len(rank[0,:])): 
        if (rank[i,j] == query_label[i]):   ##if match, set 1, otherwise set 0
            rank_bin.append(1)
        else:
            rank_bin.append(0)
    rank_bin1.append(rank_bin)
    
    
rank_bin1 = np.asarray(rank_bin1)   ##array of label matches and mismatches
print(rank_bin1)


# In[252]:


rank_1 = np.sum(rank_bin1[:,0])/1400
r5 = rank_bin1[:,:5].sum(axis = 1)/5
rank_5 = np.count_nonzero(r5)/1400
r10 = rank_bin1[:,:10].sum(axis = 1)/5
rank_10 = np.count_nonzero(r10)/1400

print("Accuracy")
print("rank 1: %s" % (rank_1))
print("rank 5: %s" % (rank_5))
print("rank 10: %s" % (rank_10))


# ### Plotting PCA

# In[245]:


import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
print(gallery_f_pca.shape)
#fig1=plt.figure()
#ax1=fig1.add_subplot(111, projection ='3d')
figpca = plt.figure()
ax=figpca.add_subplot(111, projection ='3d')
xs1=gallery_f[:,0]
ys1=gallery_f[:,1]
zs1=gallery_f[:,2]
xs=gallery_f_pca[2000:4000,0]
ys=gallery_f_pca[2000:4000,1]
zs=gallery_f_pca[2000:4000,2]
xs2=gallery_f_pca[:2000,0]
ys2=gallery_f_pca[:2000,1]
zs2=gallery_f_pca[:2000,2]
xs3=gallery_f_pca[4000:5324,0]
ys3=gallery_f_pca[4000:5324,1]
zs3=gallery_f_pca[4000:5324,2]
#colmap = cm.ScalarMappable(cmap=cm.hsv)
#colmap.set_array(zs)
#cb1=fig1.colorbar(colmap)
#cb = figpca.colorbar(colmap)
ax.scatter(xs,ys,zs,c='g')
ax.scatter(xs2,ys2,zs2,c='g')
ax.scatter(xs3,ys3,zs3,c='g')
#ax1.scatter(xs1,ys1,zs1,c='y')
#ax1.set_xlabel('first component')
#ax1.set_ylabel('second component')
#ax1.set_zlabel('third component')
ax.set_xlabel('PCA rep of 1st')
ax.set_ylabel('PCA rep of 2nd')
ax.set_zlabel('PCA rep of 3rd')
#plt.savefig('without pca first 3 columns.png', format='png', dpi=300)
plt.savefig('with pca first 3 columns.png', format='png', dpi=300)
plt.show()


# ## KPCA

# In[133]:


train_f = np.vstack((train_f.T, train_label, train_camid)) #transpose feature matrix to match dimensions 

train_f = train_f.T


# In[134]:


#kernelPCA with cosine 


k = 10 #number of nearest neighbors parameter

rank = []
distance = []
idx = []

import time
start_time = time.time()

##sqeuclidean instead of euclidean for computing efficientcy. As we are only interested in the ranklists
##and not the actual values of the distances.

for i in range (len(query[:,0])):
    
    ##getting rid of label/camid repetions 
    gallery_no_rep = gallery[~np.logical_and((gallery[:,-1] == query[i, -1]), (gallery[:,-2] == query[i, -2]))]
    
    query_f_test = query_f[i,:].reshape(1,-1)
    query_f_kpca = kpca.transform(query_f_test)

    gallery_f_kpca = kpca.transform(gallery_no_rep[:,:-2])
    
    NN = NearestNeighbors(n_neighbors = k, metric = 'sqeuclidean') #setting up NN
    NN.fit(gallery_f_kpca, gallery_no_rep[:,-2])

   
    #query_f_test = query_f[i,:].reshape(1,-1)
    distkpca, idxskpca = NN.kneighbors(query_f_kpca)
    
    distance.append(distkpca)
    idx.append(idxskpca)

distance = np.asarray(distance)
idx = np.asarray(idx)

print(idx.shape)

##creating ranklist of predicted labels (1400x10)
for i in range (len(query[:,0])):
    row_rank = []
    for j in range (len(idx[0,:])):
        row_rank.append(gallery[idx[i,j],-2])
    rank.append(row_rank)
    
rank = np.asarray(rank)     

    
print("--- %s seconds ---" % (time.time() - start_time))

print(rank.shape)


# In[135]:


rank = np.squeeze(rank)
print(rank.shape)
print(rank)


# In[136]:


query_label = query_label.reshape(1400,1)

rank_bin1 = []

for i in range (len(rank[:,0])):
    rank_bin = []
    for j in range (len(rank[0,:])): 
        if (rank[i,j] == query_label[i]):   ##if match, set 1, otherwise set 0
            rank_bin.append(1)
        else:
            rank_bin.append(0)
    rank_bin1.append(rank_bin)
    
    
rank_bin1 = np.asarray(rank_bin1)   ##array of label matches and mismatches
print(rank_bin1)


# In[137]:


rank_1 = np.sum(rank_bin1[:,0])/1400
r5 = rank_bin1[:,:5].sum(axis = 1)/5
rank_5 = np.count_nonzero(r5)/1400
r10 = rank_bin1[:,:10].sum(axis = 1)/5
rank_10 = np.count_nonzero(r10)/1400

print("Accuracy")
print("rank 1: %s" % (rank_1))
print("rank 5: %s" % (rank_5))
print("rank 10: %s" % (rank_10))


# ### LMNN

# In[ ]:


## large margin nearest neighbour 


# In[63]:


# this is our data
X = query_f
# these are our constraints
Y = gallery_f

# function to plot the results
def plot(X, Y):
    x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
    y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
    plt.figure(2, figsize=(8, 6))

    # clean the figure
    plt.clf()

    plt.scatter(X[:, 0], X[:, 1],cmap=plt.cm.Paired)
    plt.xlabel('Sepal length')
    plt.ylabel('Sepal width')

    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    plt.xticks(())
    plt.yticks(())

    plt.show()
    


# In[128]:


from metric_learn import LMNN
from mpl_toolkits.mplot3d import Axes3D

k = 5 

rank = []
distance = []
idx = []

import time
start_time = time.time()

lmnn = LMNN(k,learn_rate = 1e-6)
lmnn.fit(train_f, train_label)

for i in range (len(query[:,0])):
    
    ##getting rid of label/camid repetions 
    gallery_no_rep = gallery[~np.logical_and((gallery[:,-1] == query[i, -1]), (gallery[:,-2] == query[i, -2]))]
    
    query_f_test = query_f[i,:].reshape(1,-1)
    query_f_lmnn = lmnn.transform(query_f_test)

    gallery_f_lmnn = lmnn.transform(gallery_no_rep[:,:-2])

    
    NN = NearestNeighbors(n_neighbors = k, metric = 'sqeuclidean') #setting up NN
    NN.fit(gallery_f_lmnn, gallery_no_rep[:,-2])
    
    dist, idxs = NN.kneighbors(query_f_lmnn)
    
    distance.append(dist)
    idx.append(idxs)

distance = np.asarray(distance)
idx = np.asarray(idx)

print(idx.shape)

##creating ranklist of predicted labels (1400x10)
for i in range (len(query[:,0])):
    row_rank = []
    for j in range (len(idx[0,:])):
        row_rank.append(gallery[idx[i,j],-2])
    rank.append(row_rank)
    
rank = np.asarray(rank)     

    
print("--- %s seconds ---" % (time.time() - start_time))

print(rank.shape)


# In[129]:


rank = np.squeeze(rank)
print(rank.shape)
print(rank)


# In[130]:


query_label = query_label.reshape(1400,1)

rank_bin1 = []

for i in range (len(rank[:,0])):
    rank_bin = []
    for j in range (len(rank[0,:])): 
        if (rank[i,j] == query_label[i]):   ##if match, set 1, otherwise set 0
            rank_bin.append(1)
        else:
            rank_bin.append(0)
    rank_bin1.append(rank_bin)
    
    
rank_bin1 = np.asarray(rank_bin1)   ##array of label matches and mismatches
print(rank_bin1)


# In[131]:


rank_1 = np.sum(rank_bin1[:,0])/1400
r5 = rank_bin1[:,:5].sum(axis = 1)
rank_5 = np.count_nonzero(r5)/1400
r10 = rank_bin1[:,:10].sum(axis = 1)
rank_10 = np.count_nonzero(r10)/1400

print("Accuracy")
print("rank 1: %s" % (rank_1))
print("rank 5: %s" % (rank_5))
print("rank 10: %s" % (rank_10))

